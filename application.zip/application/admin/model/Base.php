<?php

namespace app\admin\model;

class Base extends \app\common\model\Base
{



}